﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Travel
{
    class ControlInfo
    {
        public int beginYear;
        public int beginMonth;
        public int beginDay;
        public String cityName;
        public String usingTableName;
        public List<String> tableName;//本地共有多少张表
        public String yuluApiKey = "0fbf0633fa09469db9e9e6a0761caa4b";//经典语录Api
    }
}