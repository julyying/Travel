﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Travel.CsYulu
{
    class YuluFromAPI
    {
        public int error_code;
        public String reason;
        public YuluData result;
    }
}
