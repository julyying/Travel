﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Travel.CsYulu
{
    class Yulu
    {
        public String Content;
        public Yulu()
        {

        }
        public Yulu(String str)
        {
            Content = str;
        }
        public void Show(TextBlock tb)
        {
            tb.Text = Content;
        }
    }
}
