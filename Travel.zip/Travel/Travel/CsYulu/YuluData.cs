﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace Travel.CsYulu
{
    class YuluData
    {
        public int PageIndex;
        public int PageSize;
        public int Count;
        //本地信息
        public int pYulu;//当前显示的语录

        public List<Yulu> List;
        public YuluData()
        {
            pYulu = 0;
            List = new List<Yulu>();
        }
        public void ShowOne(TextBlock tb)
        {
            if (List == null || List.Count == 0 || pYulu >= List.Count)
            {
                return;
            }
            List[pYulu].Show(tb);
            Change();
        }
        private void Change()
        {
            Random rand = new Random();
            pYulu = rand.Next(0, List.Count);
        }
    }
}
