﻿using Travel.CsYulu;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using SplitPage.Xaml;
namespace Travel
{
    class Control
    {
        private ControlInfo ctrlInfo;//简单数据都存在里面
        private StorageFile infoFile;//用来读写数据
        private Table table;
        private DateTime beginDate;
        private YuluData yuluData;

        public Control()
        {
        }
        private async Task Read()
        {
            StorageFile file = infoFile;
            if (file != null)
            {
                try
                {
                    string jsonString = await FileIO.ReadTextAsync(file);
                    ctrlInfo = JsonConvert.DeserializeObject<ControlInfo>(jsonString);
                    if (ctrlInfo == null)
                    {
                        ctrlInfo = new ControlInfo();
                    }
                    if (ctrlInfo.tableName.Count == 0)
                    {
                        ctrlInfo.usingTableName = "我的课表";
                        ctrlInfo.tableName.Add(ctrlInfo.usingTableName);
                    }
                    beginDate = ctrlInfo.GetBeginDateTime();
                    table = new Table(ctrlInfo.usingTableName);
                    await table.CreateFile();//创建表的同名文件以存储（读取）课程信息，等待其创建完成再进行下一步
                    await table.ReadLecturesFromFile();//让table读取存档
                }
                catch (FileNotFoundException)
                {
                }
            }

        }
        private async Task Save()
        {
            StorageFile file = infoFile;
            if (file != null)
            {
                try
                {
                    string jsonString = JsonConvert.SerializeObject(ctrlInfo);//将对象转换成json存储
                    if (!String.IsNullOrEmpty(jsonString))
                    {
                        await FileIO.WriteTextAsync(file, jsonString);
                    }
                    else
                    {
                    }
                }
                catch (FileNotFoundException)
                {
                }
            }
        }
        private async void ChangeYulu()
        {
            ctrl.ShowYulu(yuluBlock);
        }
        public void ShowYulu(TextBlock tb)
        {
            if (yuluData != null)
                yuluData.ShowOne(tb);
        }
        private async Task<YuluData> GetYuluData()
        {
            YuluData yulus = null;
            //用api获取
            if (ctrlInfo != null && ctrlInfo.yuluApiKey != null)
            {
                Random rand = new Random();
                String uri = "http://apis.haoservice.com/lifeservice/JingDianYulu?typeId=" + rand.Next(1, 17) + "&key=" + ctrlInfo.yuluApiKey;
                YuluFromAPI yuluFromAPI = null;
                try
                {
                    var client = new HttpClient(); // Add: using System.Net.Http;
                    var response = await client.GetAsync(new Uri(uri));
                    string jsonString = await response.Content.ReadAsStringAsync();
                    yuluFromAPI = JsonConvert.DeserializeObject<YuluFromAPI>(jsonString);
                    if (yuluFromAPI.reason == "Success")
                    {
                        yulus = yuluFromAPI.result;
                        yulus.List.Add(new Yulu("我的课程表，时尚时尚最时尚！"));
                        yulus.List.Add(new Yulu("当我第一次知道要写程序的时候，其实我是拒绝的，因为我觉得，你不能让我写我就马上写，第一我要试一下，因为不可能加点代码“duang”的一下就写出来，很酷，很炫，很时尚……"));
                        yulus.List.Add(new Yulu("在空白处右键可以呼叫工具栏！"));
                        yulus.List.Add(new Yulu("左上角的“周数”其实是可以点的，右上角的课表名、城市名也是可以点的，哪里不爽点哪里！"));
                        yulus.List.Add(new Yulu("动态磁贴会告诉你下节课是神马、今天有几节课、明天有几节课……"));
                        yulus.List.Add(new Yulu("很多东西只要点下其他地方它就消失了！"));
                        yulus.List.Add(new Yulu("这些话很多是当你进入程序时从网上下载的，但很明显这句不是"));
                        yulus.List.Add(new Yulu("动态磁贴只会提醒你正在使用的课表信息，也就是你最后一次看到的课表！"));
                        yulus.List.Add(new Yulu("感谢haoservice提供的免费API，可惜每天只能访问50次（免费版的痛），所以没事就别点进来玩啦，有课会通知你的（前提是你开启了提醒功能）"));
                        yulus.List.Add(new Yulu("教务处导入功能只支持“西南科技大学”，其他学校懒得写了~"));
                        yulus.List.Add(new Yulu("炫彩模式，每次进来都不一样！"));
                        yulus.List.Add(new Yulu("空白处右键选择设置—>显示设置，可打开炫彩模式开关！（这么炫为什么要关？）"));
                        yulus.List.Add(new Yulu("某讲有多门课程时优先显示当前周要上的课！"));
                        return yulus;
                    }
                }
                catch { }
            }
            //网络获取失败，读取本地
            String path = @"myCourse\yuluData.dat";
            StorageFolder storageFolder = KnownFolders.MusicLibrary;
            StorageFile file = await storageFolder.CreateFileAsync(path, CreationCollisionOption.OpenIfExists);
            if (file != null)
            {
                try
                {
                    string jsonString = await FileIO.ReadTextAsync(file);
                    yulus = JsonConvert.DeserializeObject<YuluData>(jsonString);
                }
                catch (FileNotFoundException) { }
            }
            if (yulus == null)
            {
                yulus = new YuluData();
                yulus.List.Add(new Yulu("我的课程表，时尚时尚最时尚！"));
                yulus.List.Add(new Yulu("当我第一次知道要写程序的时候，其实我是拒绝的，因为我觉得，你不能让我写我就马上写，第一我要试一下，因为不可能加点代码“duang”的一下就写出来，很酷，很炫，很时尚……"));
                yulus.List.Add(new Yulu("在空白处右键可以呼叫工具栏！"));
                yulus.List.Add(new Yulu("左上角的“周数”其实是可以点的，右上角的课表名、城市名也是可以点的，哪里不爽点哪里！"));
                yulus.List.Add(new Yulu("动态磁贴会告诉你下节课是神马、今天有几节课、明天有几节课……"));
                yulus.List.Add(new Yulu("很多东西只要点下其他地方它就消失了！"));
                yulus.List.Add(new Yulu("这些话很多是当你进入程序时从网上下载的，但很明显这句不是"));
                yulus.List.Add(new Yulu("动态磁贴只会提醒你正在使用的课表信息，也就是你最后一次看到的课表！"));
                yulus.List.Add(new Yulu("感谢haoservice提供的免费API，可惜每天只能访问50次（免费版的痛），所以没事就别点进来玩啦，有课会通知你的（前提是你开启了提醒功能）"));
                yulus.List.Add(new Yulu("教务处导入功能只支持“西南科技大学”，其他学校懒得写了~"));
                yulus.List.Add(new Yulu("炫彩模式，每次进来都不一样！"));
                yulus.List.Add(new Yulu("空白处右键选择设置—>显示设置，可打开炫彩模式开关！（这么炫为什么要关？）"));
                yulus.List.Add(new Yulu("某讲有多门课程时优先显示当前周要上的课！"));
            }
            return yulus;
        }
        private async Task SaveYuluData()
        {
            String path = @"myCourse\yuluData.dat";
            StorageFolder storageFolder = KnownFolders.MusicLibrary;
            StorageFile file = await storageFolder.CreateFileAsync(path, CreationCollisionOption.OpenIfExists);
            if (file != null)
            {
                try
                {
                    string jsonString = JsonConvert.SerializeObject(yuluData);//将对象转换成json存储
                    if (!String.IsNullOrEmpty(jsonString))
                    {
                        await FileIO.WriteTextAsync(file, jsonString);
                    }
                }
                catch (FileNotFoundException) { }
            }
        }
       
    }
}